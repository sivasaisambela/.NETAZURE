# Replace the following URL with a public GitHub repo URL
$gitrepo="stry"
$gittoken="isat"
$webappname="svcname$(Get-Random)"
$location="West Europe" 
$rgName="resgroup"
$branch="sourcebrnch"
$azureorgst="azorg"
$azuretoken="aztoken"
$azurerepo="azrepon"
$azureprj="azprjc"



Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Force -Scope CurrentUser
Install-Module AzureAD -Force -Scope CurrentUser
Install-Module -Name MSOnline -Force -Scope CurrentUser
Import-Module Az -Force -Scope CurrentUser
Install-Module Az -Force  -Scope CurrentUser





az login;

az repos create --name $azurerepo --org $azureorgst --project $azureprj;
az repos import create --git-source-url $gitrepo --repository $azurerepo --organization $azureorgst --project $azureprj;
