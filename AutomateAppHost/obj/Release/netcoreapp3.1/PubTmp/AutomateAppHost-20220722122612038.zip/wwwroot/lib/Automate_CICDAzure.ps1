# Replace the following URL with a public GitHub repo URL
$gitrepo="stry"
$gittoken="isat"
$webappname="svcname$(Get-Random)"
$location="West Europe" 
$rgName="resgroup"
$branch="sourcebrnch"
$azureorgst="azorg"
$azuretoken="aztoken"
$azurerepo="azrepon"
$azureprj="azprjc"



$siteURL = "http://intranet/"
$site = Get-SPWeb($siteURL)

    foreach ($web in $site.Site.AllWebs)

Set-ExecutionPolicy -ExecutionPolicy unrestricted -Scope CurrentUser


Import-module -name azure -force -Scope Global



Connect-AzAccount

az login;

az repos create --name $azurerepo --org $azureorgst --project $azureprj;
az repos import create --git-source-url $gitrepo --repository $azurerepo --organization $azureorgst --project $azureprj;
