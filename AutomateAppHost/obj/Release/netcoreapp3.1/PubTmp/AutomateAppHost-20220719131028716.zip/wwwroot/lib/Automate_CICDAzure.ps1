# Replace the following URL with a public GitHub repo URL
$gitrepo="stry"
$gittoken="isat"
$webappname="svcname$(Get-Random)"
$location="West Europe" 
$rgName="resgroup"
$branch="sourcebrnch"
$azureorgst="azorg"
$azuretoken="aztoken"
$azurerepo="azrepon"
$azureprj="azprjc"




Install-Module Az

Import-Module Az.Websites -Verbose
Import-Module Az.Resources -Verbose







az login
az repos create --name $azurerepo --org $azureorgst --project $azureprj
az repos import create --git-source-url $gitrepo --repository $azurerepo --organization $azureorgst --project $azureprj
